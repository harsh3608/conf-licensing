export const environment = {
    production: false,
    server: 'http://localhost:4200/', 
    apiUrl: 'api',
};