export const environment = {
    production: true,
    server: 'https://licenseapp-dev.azurewebsites.net/', 
    apiUrl: 'https://devlicenseingapi.azurewebsites.net/',
};