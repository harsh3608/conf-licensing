
export class Constants{

    // public static baseServerUrl: string = 'https://devlicenseingapi.azurewebsites.net/api/';
    public static baseServerUrl: string = 'https://localhost:44328/api/';

}



